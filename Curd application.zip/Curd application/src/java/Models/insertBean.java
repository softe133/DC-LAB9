/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Models;

/**
 *
 * @author haffs
 */
public class insertBean {
    private String name;
    private String rollno;
    private String cnic;
    private String email;
    private String contactno;
    
    public String getUsername() {  
    return name;  
}  
public void setUsername(String name) {  
    this. name= name;  
}  
public String getRollno() {  
    return rollno;  
}  
public void setRollno(String rollno) {  
    this.rollno = rollno;  
}  

public String getContact(){
return contactno;
}

public void setContactno(String contactno){
this.contactno = contactno;
}
public String getCnic(){
return cnic;
}

public void setCnictno(String cnic){
this.cnic = cnic;
}
public String getEmail(){
return email;
}

public void setEmail(String email){
this.email = email;
}

      
}
